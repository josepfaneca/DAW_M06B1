var llista;
var componentRAM;
var componentCPU;
/**
*   Mètode inicialitza, ja codificat. No es pot modificar.
*	Inicialitza la variable global llista com a vector sense cap element.
*   Inicialitza les variables globals componentRAM i componentCPU com a vectors
*   Afegeix a aquests dos últims, tres RAM i tres CPU respectivament
*	Crida al mètode afegeixSelectors
*/
function inicialitza(){
	llista=[];
	componentRAM=[];
	componentCPU=[];

	componentRAM.push(new RAM(4,12.99));
	componentRAM.push(new RAM(8,21.50));
	componentRAM.push(new RAM(16,37));
	componentCPU.push(new CPU("i3-5500",110));
	componentCPU.push(new CPU("i3-5900",115.5));
	componentCPU.push(new CPU("i5-2500",144.9));

	afegeixSelectors();
}
/**
*   Mètode afegeixSelectors, ja codificat. No es pot modificar.
*	Afegeix al selector de RAM, les memòries RAM
*	Afegeix al selector de CPU, les CPU
*/
function afegeixSelectors()
{

	var selRam=document.getElementById("selectRAM");
	var selCpu=document.getElementById("selectCPU");
	for(var i=0;i<componentRAM.length;i++)
	{
		var opt = document.createElement("option");
		opt.value= componentRAM[i].getQuantitat();
		opt.innerHTML = componentRAM[i].mostrar();
		selRam.appendChild(opt);
	}
	for(var i=0;i<componentCPU.length;i++)
	{
		var opt = document.createElement("option");
		opt.value= componentCPU[i].getModel();
		opt.innerHTML = componentCPU[i].mostrar();
		selCpu.appendChild(opt);
	}
}
/**
*  Cerca un pc
*   @param {string} model  model del pc a cercar
*   @returns {int}  posicio on es troba el model cercat, -1 si no existeix
*/
function cercarPC(model)
{
	
	var posicio=-1;
	for(var i=0;i<llista.length && posicio==-1;i++){

		if(llista[i].getModel()==model) posicio=i;
	}
	return posicio;
}
/**
*   Afegeix un pc al principi del llistat
*   Crida al mètode cercarPC. Si ja existeix un PC amb aquell nom de model, mostra un error. 
*	Si no existeix crida al mètode afegir passant-li un -2 (afegir per davant)
*/
function afegirPCInici()
{
	var m=document.getElementById("nom").value;
	var posicio=cercarPC(m);
	if(posicio!=-1) {alert("Aquest model ja existeix.")}
	else{afegeix(-2);}
}
/**
*   Afegeix un pc al final del llistat
*   Crida al mètode cercarPC. Si ja existeix un PC amb aquell nom de model, mostra un error. 
*	Si no existeix crida al mètode afegir passant-li un -1 (afegir per darrera)
*/
function afegirPCFinal()
{
	var m=document.getElementById("nom").value;
	var posicio=cercarPC(m);
	if(posicio!=-1) {alert("Aquest model ja existeix.")}
	else{afegeix(-1);}
}
/**
*   Modifica el pc amb el nom indicat
*   Crida al mètode cercarPC. Si no existeix un PC amb aquell nom de model, mostra un error. 
*	Si existeix crida al mètode afegir passant-li la posició a modificar 
*/
function modificarPC()
{
	var m=document.getElementById("nom").value;
	var posicio=cercarPC(m);
	if(posicio==-1) {alert("Aquest model no existeix.")}
	else{afegeix(posicio);}
}
/**
*   Afegeix o modifica un pc
*   @param {int} posicio a modificar, -1 si vui afegir-lo al final, o -2 si vui afegir-lo a l'inici
*   Si s'ha indicat un -1, afegeixo el pc al final de la llista
*   Si s'ha indicat un -2, afegeixo el pc al principi de la llista
*	Si s'ha indicat un numero diferent, modifico el PC d'aquella posició
*/
function afegeix(posicio){  
	var selRam=document.getElementById("selectRAM");
	var selCpu=document.getElementById("selectCPU");
	var model=document.getElementById("nom").value;
	var preu=document.getElementById("preu").value;
	if(posicio==-1) {llista.push(new PC(model, preu, componentRAM[selRam.selectedIndex], componentCPU[selCpu.selectedIndex]));}
	else if (posicio==-2) {llista.splice(0,0,new PC(model, preu, componentRAM[selRam.selectedIndex], componentCPU[selCpu.selectedIndex])); }
	else
	{
		//modificar
		llista[posicio].setPreu(preu);
		llista[posicio].setRAM(componentRAM[selRam.selectedIndex]);
		llista[posicio].setCPU(componentCPU[selCpu.selectedIndex]);
	}
	refresca();  
}


/**
*  Elimina del vector el PC amb el nom indicat al camp model del formulari
*/

function eliminarPC()
{
	var text= document.getElementById("nom").value;
	llista=llista.filter(function (obj){
			return obj.getModel()!=text;
	});
	refresca();  
}

/************************************************************************************************************************/
/**
*   Crea una RAM. Ja codificat. No es pot modificar.
*   @param {int} quantitat de RAM
*	@param {float} preu de la RAM
*   @constructor
*	getters de Quantitat i preu. Setters de Quantitat
*	Mètode mostrar, que retorna un string amb la quantitat i el preu
*/

function RAM(_quantitat,_preu)
{
	this.getQuantitat=function(){return _quantitat;};
	this.setQuantitat=function(q){_quantitat=q;}
	this.getPreu=function(){return _preu;}
	this.mostrar=function(){return _quantitat+"("+_preu+"€)";}
}
/**
*   Crea una CPU. Ja codificat. No es pot modificar.
*   @param {String} model de CPU
*	@param {float} preu de la CPU
*   @constructor
*	getters de model i preu. Setters de model
*	Mètode mostrar, que retorna un string amb el model i el preu
*/
function CPU(_model,_preu)
{
	this.getModel=function(){return _model;};
	this.setModel=function(q){_model=m;}
	this.getPreu=function(){return _preu;}
	this.mostrar=function(){return _model+"("+_preu+"€)"}
}
/**
*   Crea un PC
*   @param {string} nom  nom del model de PC
*	@param {float} preu del PC
*	@param {RAM} objecte del tipus RAM
*	@param {CPU} Objecte del tipus CPU
*   @constructor
*	getters de Model. Setters de Preu, RAM i CPU.   
*	getPreu: retorna la suma del preu del PC+el preu de la RAM+ el preu de la CPU
*	Crea el mètode mostrar que retorna un string amb el nom del model, el nom i preu de la CPU, la quantitat i preu de la RAM, i el preu total (getPreu)
*
*/

function PC(_nom,_preu,_ram,_cpu){
	this.getModel=function(){ return _nom;}
	this.getPreu=function(){ return parseFloat(_preu)+parseFloat(_ram.getPreu())+parseFloat(_cpu.getPreu());}
	this.setPreu=function(p){ _preu=p;}
	this.setRAM=function(r){ _ram=r;}
	this.setCPU=function(c){ _cpu=c;}
	this.mostrar=function()
	{
		var resultat="Nom:"+_nom+", CPU:"+_cpu.mostrar()+", RAM:"+_ram.mostrar()+", preu Total:"+this.getPreu();
		return resultat;
	}
}

/**
* 	 Dibuixa a la divisió anomenada ofertes, tots els PC del vector llista.
*	 Per cada PC, crida al mètode mostrar de l'objecte PC
*	 Al costat de cada PC crea un checkbox, que com a identificador té la paraula "pc" seguit del número de posició del PC en el vector
*	 En acabar tots els PC, afegeix un boto amb el text "Comprar", i que quan es premi, haurà d'executar el mètode comprar
*	 
*/


function refresca(){
	var resultat="";
	
	document.getElementById("ofertes").innerHTML="";
	for(var i=0;i<llista.length;i++){

		resultat+="<p>"+llista[i].mostrar()+"<input type='checkbox' id='pc"+i+"'/></p>";
	}
	document.getElementById("ofertes").innerHTML=resultat+"<input type='button' value='Comprar' onclick='comprar()'>";
	
}

/**
*	Mostra un alerta indicant quants pc s'han comprat, i l'import total de la compra. Elimina els PC comprats del vector llista
*	Per fer-ho:
*		Recorre els checkbox anomenats pcX, creats en el mètode refresca, on la x és la posició del PC en el vector llista
*		Si estan marcats, acumula el preu del pc, incrementa el comptador de pc's comprats, i elimina el PC de la llista
*/
function comprar()
{
	var total=0;
	var quant=0;
	for(var i=llista.length-1;i>=0;i--)
	{
		if(document.getElementById("pc"+i).checked)
		{
			total+=parseFloat(llista[i].getPreu());
			llista.splice(i,1);
			quant++;
		}
	}
	alert("S'han comprat "+quant+" PCS amb un import total de "+total);
	refresca();
}



