// variables globals
var llistats;      // element HTML on es mostraràn els llistats de les cerques
var selectorMunicipi;  // camp selector HTML pel selector del municipi
var selectorEspecie;  // camp selector HTML pel selector de l'espècie
var troballes;	// és un vector amb les troballes, amb el format municipi@especie@quantitat
//*************FUNCIONS GENERALS*******************//
/**
*    Inicialitza les variables globals;
*    (les que corresponen a elements HTML no es poden inicialitzar abans,
*     s'han d'inicialitzar després del load de la pàgina)
*/
function inicialitza(){
    troballes=[];
    llistats=document.getElementById("llistats");
    selectorMunicipi=document.getElementById("selectMunicipi");
    selectorEspecie=document.getElementById("selectEspecie");
}
/**
*   Comprova que hi hagi algo escrit al camp de text.
*   @param {camp} - valor del camp de text
*   @returns {boolean} - retorna false, si no hi ha text. Si n'hi ha retorna true
*/
function checkText(camp)
{
	if(camp==null || camp.length==0) return false;
	else return true;
	
}

/**
*   Afegeix una opció a un select.
*   Rep l'element HTML select i el valor a afegir
*   @param {select} - select element HTML
*   @param {String} - valor de la opció
*/
function afegeixOpcioSelector(selector, nom) {
	var opcioElem = document.createElement("option");
    opcioElem.value = nom;
    opcioElem.text = nom;
    selector.add(opcioElem);
}

/**
*   Elimina una opció d'un select.
*	Rep l'element HTML select i el valor de la opcio a esborrar
*   @param {select} - select element HTML
*   @param {String} - valor de la opció
*/
function eliminaOpcioSelector(selector,nom) {

	for (var i= 0; i< selector.options.length; i++) {
		if (selector.options[i].value==nom) {
			selector.remove(i); //index
			break;
		}
	}
}
/**
*   Busca si existeix un element a un selector.
*	Rep l'element HTML select i el valor de la opcio a cercar
*   @param {select} - select element HTML
*   @param {String} - valor de la opció
*	@returns {Integer} - retorna la posció de l'ement. Si no existeix retorna -1
*/
function cerca(selector,nom) {

	for (var i= 0; i< selector.options.length; i++) {
		if (selector.options[i].value==nom) {
			return i;
		}
	}
	return -1;
}
/**
*   Elimina del vector de troballes tots els elements que coincideixin amb el nom indicat
*	segons el tipus (0 municipi, 1 especie)
*   @param {String} - nom de l'element a cercar i eliminar
*   @param {Integer} - tipus de l'element, 0 municipi i 1 espècie
*	@returns {Integer} - retorna la quantitat d'elements eliminats
*/

function eliminaTroballa(nom,tipus)
{
	var quants=0;
	for (var i= 0; i< troballes.length; i++) {
		var aux=troballes[i].split("@");
		if(aux[tipus]==nom){ troballes.splice(i,1); i--; quants++;}
		}
	
	return quants;
}

//*************GESTIO DE MUNICIPIS*******************//
/**
*    Dona d'alta un municipi
*	 si no s'ha introduït text a la caixa de text, dona un error.
*    si existeix un municipi amb el mateix nom, dona un error.
*    altrament crea una municipi, cirdant a la funció afegeixOpcioSelector per afegir el nom del nou Municipi al desplegable
*/


function altaMunicipi()
{
	var nom=document.getElementById("nomMunicipi").value;
	if(!checkText(nom)){alert ("Introdueix un nom pel Municipi!"); return;}
	if(cerca(selectorMunicipi,nom)!=-1) {alert ("Aquest municipi ja existeix!"); return;}
	else{afegeixOpcioSelector(selectorMunicipi,nom);}
}
/**
*    Elimina un municipi i totes les troballes en aquell municipi
*	 si no s'ha introduït text a la caixa de text, dona un error.
*    si no existeix un municipi amb el nom indicat, dona un error.
*    altrament elmimina de l'array de troballes, tots els elements on apareix aquell municipi
*	 i mostra una alerta amb quantes troballes s'han eliminat
*	 Després crida a la funció eliminaOpcioSelector per eliminar el municipi del desplegable
*/
function eliminaMunicipi()
{
	var nom=document.getElementById("nomMunicipi").value;
	if(!checkText(nom)){alert ("Introdueix un nom pel Municipi!"); return;}
	if(cerca(selectorMunicipi,nom)==-1) {alert ("Aquest municipi no existeix!"); return;}
	var quants=eliminaTroballa(nom,0);
	alert("s'han eliminat "+quants+" troballes al municipi "+nom);
	eliminaOpcioSelector(selectorMunicipi,nom);
}

//*************GESTIO D'ESPECIES*******************//
/**
*    Dona d'alta una espècie
*	 si no s'ha introduït text a la caixa de text, dona un error.
*    si existeix una espècie amb el mateix nom, dona un error.
*    altrament crea una espècie, cirdant a la funció afegeixOpcioSelector per afegir el nom de la nova espècie al desplegable
*/

function altaEspecie()
{
	var nom=document.getElementById("nomEspecie").value;
	if(!checkText(nom)){alert ("Introdueix un nom per l'Especie!"); return;}
	if(cerca(selectorEspecie,nom)!=-1) {alert ("Aquesta especie ja existeix!"); return;}
	else{afegeixOpcioSelector(selectorEspecie,nom);}
}
/**
*    Elimina una Especie i totes les troballes d'aquella espècie
*	 si no s'ha introduït text a la caixa de text, dona un error.
*    si no existeix l'Especie amb el nom indicat, dona un error.
*    altrament elmimina de l'array de troballes, tots els elements on apareix aquella Especie
*	 i mostra una alerta amb quantes troballes s'han eliminat
*	 Després crida a la funció eliminaOpcioSelector per eliminar l'Especie del desplegable
*/
function eliminaEspecie()
{
	var nom=document.getElementById("nomEspecie").value;
	if(!checkText(nom)){alert ("Introdueix un nom per l'Especie!"); return;}
	if(cerca(selectorEspecie,nom)==-1) {alert ("Aquesta especie no existeix!"); return;}
	var quants=eliminaTroballa(nom,1);
	alert("s'han eliminat "+quants+" troballes de l'espècie: "+nom);
	eliminaOpcioSelector(selectorEspecie,nom);
}

//*************GESTIO DE TROBALLES*******************//
/**
*    Afegeix una troballa al vector de troballes
*	 Si no s'ha indicat una quantitat, es mostra un error i no s'afegeix res al vector troballes
*	 Una troballa esta formada pel municipi seleccionat, l'espècie seleccionada, i la quantitat trobada, separats pel caràcter @
*    mostra una alerta indicant que s'ha pogut afegir
*/
function altaTroballa()
{
	if (selectorMunicipi.selectedIndex==-1) {alert("Selecciona un municipi!");return;}
	if (selectorEspecie.selectedIndex==-1) {alert("Selecciona una espècie!");return;}
	var municipiSeleccionat = selectorMunicipi.options[selectorMunicipi.selectedIndex].value;
	var especieSeleccionada = selectorEspecie.options[selectorEspecie.selectedIndex].value;
	var quantitat=-1;
	if(document.getElementById("molts").checked) quantitat=1;
	else if(document.getElementById("bastants").checked) quantitat=2;
	else if(document.getElementById("pocs").checked) quantitat=3;
	if (quantitat==-1) {alert("Selecciona una quantitat!");return;}
	troballes.push(municipiSeleccionat+"@"+especieSeleccionada+"@"+quantitat);	
}

//*************GESTIO DE LA INFORMACIÓ*******************//
/**
*    Llista les troballes ordenades per nom de l'espècie
*	 Genera un vector amb les troballes ordenades i crida al mètode dibuixar, 
*    passant-li el vector, la paraula "espècies", i indicant que el camp de quantitat és el 2
*/
function llistaEspecies() //ordenar per espeice
{
	//copio troballes a un segon vector, desfent el "@" (canviant el ordre)
	var troballesNou=[];
	for(var i=0;i<troballes.length;i++)
	{
		var separat=troballes[i].split("@");
		var aux=separat[0];
		separat[0]=separat[1];
		separat[1]=aux;
		troballesNou.push(separat.join("@"));
	}
	troballesNou.sort();
	dibuixar(troballesNou, "especies",2);
}
/**
*    Llista les troballes ordenades per quantitat 
*    (primer els molts, després els bastants, i per últim els pocs)
*	 Genera un vector amb les troballes ordenades i crida al mètode dibuixar, 
*    passant-li el vector, la paraula "quantitat", i indicant que el camp de quantitat és el 0
*/
function llistaQuantitat() //ordenar per quantitat
{
	//copio troballes a un segon vector, desfent el "@" (canviant el ordre)
	var troballesNou=[];
	for(var i=0;i<troballes.length;i++)
	{
		var separat=troballes[i].split("@");
		var aux=separat[0];
		separat[0]=separat[2];
		separat[2]=aux;
		troballesNou.push(separat.join("@"));
	}
	troballesNou.sort();
	dibuixar(troballesNou, "quantitat",0);
}
/**
*    Llista les troballes ordenades per municipi, especie i quantitat 
*    (primer els molts, després els bastants, i per últim els pocs)
*	 Genera un vector amb les troballes ordenades i crida al mètode dibuixar, 
*    passant-li el vector, la frase "municipi, especie i quantitat", i indicant que el camp de quantitat és el 2
*/
function llistaOrdenada() //ordenar per municipi, especie, i quantitat (fer un sort)
{
	var troballesNou=troballes;
	troballesNou.sort();
	dibuixar(troballesNou,"municipi, especie i quantitat",2);
}
//*************DIBUIXAR TROBALLES*******************//
/**
*	Dibuixa les troballes. 
*	Dibuixa el vector que ens passen a la divisió llistats, substituint els valors 1-2-3 per les paraules "molts", "bastants" i "pocs" respectivament
*	
*   @param {Array} - vector per dibuixar
*   @param {String} - missatge que s'ha de mostrar al títol
*   @param {Integer} - camp quantitat en el vector
*	
*/
function dibuixar(dades,missatge,camp)
{
	
	var resultat="<h1>Llistats ordenats per "+missatge+"</h1><ul>";
	
	for (i=0;i<dades.length;i++)
	{
		var separat=dades[i].split("@");
		if(separat[camp]==1)separat[camp]="Molts";
		else if(separat[camp]==2)separat[camp]="Bastants";
		else if(separat[camp]==3)separat[camp]="Pocs";
		resultat+="<li>"+separat[0]+"  --   "+separat[1]+"  --  "+separat[2]+"</li>";
	}
	resultat+="</ul>";
	llistats.innerHTML=resultat;
}
