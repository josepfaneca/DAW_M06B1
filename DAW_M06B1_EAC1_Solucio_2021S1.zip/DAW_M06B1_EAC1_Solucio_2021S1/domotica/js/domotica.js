/**
*
* desa en 3 cookies el valor dels checkboxes, crida al mètode actualitza, i mostra una alerta.
* per gravar les cookies, cridarem 3 cops a la funció gravaCookie, amb el nom de la cookie i el valor que vulguem guardar.
*/

function desa()
{
   var c1=document.getElementById("h1");
   var c2=document.getElementById("h2");
   var c3=document.getElementById("h3");
   gravaCookie("hab1",c1.checked);
   gravaCookie("hab2",c2.checked);
   gravaCookie("hab3",c3.checked);
   actualitza();	
   alert("Dades desades!");
}
/**
*
* actualitza les imatges segons si els checkbox estan marcats o no.
*
*/
function actualitza()
{
   var i1=document.getElementById("habitacio1");
   var i2=document.getElementById("habitacio2");
   var i3=document.getElementById("habitacio3");
   var c1=document.getElementById("h1");
   var c2=document.getElementById("h2");
   var c3=document.getElementById("h3");	

   var fred="img/fred.png";
   var calor="img/calor.png";
   if(c1.checked) i1.src=calor;
   else i1.src=fred;
   if(c2.checked) i2.src=calor;
   else i2.src=fred;
   if(c3.checked) i3.src=calor;
   else i3.src=fred;

}
/**
*
* recupera els valors dels checkbox de les cookies, i actualitza els checkbox
* si no estan guardats, es considera que la calefacció estarà apagada
* crida al mètode actualitza
*
*/
function recupera()
{
   var c1=document.getElementById("h1");
   var c2=document.getElementById("h2");
   var c3=document.getElementById("h3");	
   
   
   if(obteCookie("hab1")===null) c1.checked=false;
   else if(obteCookie("hab1")=="false") c1.checked=false;
   else c1.checked=true;

   if(obteCookie("hab2")===null) c2.checked=false;
   else if(obteCookie("hab2")=="false") c2.checked=false;
   else c2.checked=true;
   
   if(obteCookie("hab3")===null) c3.checked=false;
   else if(obteCookie("hab3")=="false") c3.checked=false;
   else c3.checked=true;
   
   actualitza();	
}

/**
*
* esborra totes les dades emmagatzemades a les cookies, fent-les caducar. 
* Per fer-ho crida 3 cops a la funció esborraCookie.
* Desarca els checkboxes
* treu una alerta, i crida al mètode actualitza
*/
function reset()
{
	var c1=document.getElementById("h1");
    var c2=document.getElementById("h2");
    var c3=document.getElementById("h3");	
    esborraCookie("hab1");
    esborraCookie("hab2");
    esborraCookie("hab3");
    c1.checked=false;
    c2.checked=false;
    c3.checked=false;
    alert("Dades esborrades");
    actualitza();
}


/**
*    separa els diferents cookies de document.cookie
*
* @return {Array} vector amb els diferents cookies de la forma clau = valor
*/
function recuperaArrayCookies(){
  return document.cookie.split("; ");
}

/**
*   cerca en un vector de cookies el valor que correspon al segon parametre
*
*
*   @param {Array} nomBuscat - clau de la cookie que es cerca dinsel vector
*
* @return {Array|null} el valor que correspon a la clau indicada pel parametre nomBuscat
*   o null si no existeix aquesta clau en el vector.
*/

function obteCookie(nomBuscat){
  var arrayCookies = recuperaArrayCookies();
  console.log(arrayCookies);
  for(var i=0; i< arrayCookies.length;i++){

    var temp = arrayCookies[i].split("=");

    var nomCookie = temp[0];

    var valorCookie = temp[1];

    if(nomCookie==nomBuscat){
      return (valorCookie);
    }

  }
  return null;
}



/**
* emmagatzema les cookies amb el nom i valor indicats als paràmetres
* i el moment actual com ultim acces;
*
* @param {string} nomCookie - nom de la cookie a guardar
* @param {string} valor_cookie - valor de la cookie a guardar
* 
*/

function gravaCookie(nomCookie,valorCookie){
  var ANYS_COOKIES=10;
  var data = new Date();
  var dataExpiracio = new Date();
  dataExpiracio.setFullYear(dataExpiracio.getFullYear()+ANYS_COOKIES);
  var textExpiracio = " expires="+dataExpiracio.toString();
  document.cookie = nomCookie+" = "+valorCookie+"; "+textExpiracio;
  
}



/**
*   esborra la cookie amb la clau corresponent al parametre
*   @param {string} nomCookie - clau de la cookie a esborrar
*/
function esborraCookie(nomCookie){
  document.cookie = nomCookie+" =; expires=01 Jan 1900 00:00:00 UTC";
}
