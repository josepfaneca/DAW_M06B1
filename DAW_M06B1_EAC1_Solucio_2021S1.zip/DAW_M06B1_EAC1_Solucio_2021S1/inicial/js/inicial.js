
function executa() {
 var numero = document.getElementById("numero").value;
 var accio="";
 if(document.getElementById("accio2").checked) accio="2";
 else if(document.getElementById("accio3").checked) accio="3";
   
	if (numero.length==0){
	alert("Has d'introduir algun nombre!");
	}
    else if (isNaN(numero)){
		alert("El numero ha de ser un número!");
	}
	else if(accio=="")
	{
		alert("Has d'escollir alguna acció!")
	}
	else{
		if (accio=="2")
		{
			document.getElementById("resultat").innerHTML= Number(numero)*2;
		}
		else 
		{
			document.getElementById("resultat").innerHTML= Number(numero)*3;
		}
		
	}
       
}         
            
        
function neteja(){
    document.getElementById("numero").value="";
    document.getElementById("resultat").innerHTML="";
    document.getElementById("accio2").checked=false;
    document.getElementById("accio3").checked=false;
       
}
