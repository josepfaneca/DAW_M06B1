/**
*  Crea un nou document, es a dir, buida la divisió resultat i la caixa de text anomenada text
*/
function nou()
{
	document.getElementById("text").value="";
	document.getElementById("resultat").innerHTML="";
}
/**
*   afegeix un text a la divisió resultat, amb la mida de font indicada i els estils negreta i cursiva indicats
*   el text s'afegeix al final de la divisó resultat, sense sobreescriure el que hi havia.  
*/
function afegir()
{
    var text=document.getElementById("text").value;
    var font=document.getElementById("font").value;
    if(font=="") font=12;
    var mida="font-size:"+font+"px;";
    var negreta="",cursiva="";
    if(document.getElementById("negreta").checked) negreta="font-weight: bold;";
    if(document.getElementById("cursiva").checked) cursiva="font-style: italic;";
    var estil="<p style='"+mida+negreta+cursiva+"'>";
    var sortida=estil+text+"</p>";
	document.getElementById("resultat").innerHTML+=sortida;
}

/**
*   recupera el valor del localStorage i el situa a la divisió resultat.
*   si el valor del localStorage es null, mostra una alerta i no fa cap canvi a la divisió resultat
*/
function recuperar()
{
	if(localStorage.getItem("text")!=null) 
		document.getElementById("resultat").innerHTML=localStorage.getItem("text");
	else alert("No hi ha res a recuperar!");
}
/**
*   guarda el text que hi ha a la divisó resultat al localStorage.
*	
*/
function guardar()
{
	localStorage.setItem("text",document.getElementById("resultat").innerHTML);
}

/**
*   elimina tot el contingut del localStorage.
*	
*/
function esborrar()
{
	localStorage.clear();
	
}
