
function afegir() {
 var text = document.getElementById("text").value;
 var valor = document.getElementById("valor").value;
 var desplegable=document.getElementById("desplegable");
 var opcioElem = document.createElement("option");
    opcioElem.value = valor;
    opcioElem.text = text;
 desplegable.add(opcioElem);

}

function eliminar()
{

	var desplegable=document.getElementById("desplegable");
	desplegable.remove(desplegable.selectedIndex);
}

function buidar()
{
	var desplegable=document.getElementById("desplegable");
	for(var i = desplegable.length-1; i >= 0; i--) {
      desplegable.remove(i);
   }
}
function visualitzar()
{
	var desplegable=document.getElementById("desplegable");
	var seleccionat=desplegable.options[desplegable.selectedIndex];
	document.getElementById("resultat").innerHTML="El text seleccionat és " +seleccionat.text+ " i el seu valor és "+seleccionat.value;
}
function afegirControlant() {
 var text = document.getElementById("text").value;
 var valor = document.getElementById("valor").value;
 var desplegable=document.getElementById("desplegable");
 var trobat=false;
 for(var i = desplegable.length-1; i >= 0; i--) 
 {
      if(desplegable.options[i].value==valor) {trobat=true; break;}
 }
 if(!trobat)
 {

 	var opcioElem = document.createElement("option");
    opcioElem.value = valor;
    opcioElem.text = text;
    desplegable.add(opcioElem);
 }  
 else
 {
 	alert("Ja existeix un element amb aquest valor!");
 }
}
